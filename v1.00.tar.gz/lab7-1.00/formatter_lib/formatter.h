#pragma once

#include <string>

std::string formatter(const std::string& message);
